# MoodSync Deployment Package

This is an optimized package for deploying MoodSync to Netlify.

## Deployment Steps

1. Upload this directory to Netlify
2. Set the build command to: `npm run build`
3. Set the publish directory to: `dist/public`
4. Configure environment variables:
   - Run the included script: `./netlify-env-setup.sh` for guidance
   - Add necessary environment variables in the Netlify dashboard
   - Make sure to set NODE_VERSION=18.18.0 to avoid Node version errors
5. See NETLIFY_DEPLOYMENT.md for detailed instructions and troubleshooting

Note: This package includes only the essential files needed for building and deploying the application.
