# MoodSync Deployment Package

This is an optimized package for deploying MoodSync to Netlify.

## Deployment Steps

1. Upload this directory to Netlify
2. Set the build command to: `npm run build`
3. Set the publish directory to: `dist/client`
4. Configure environment variables as described in NETLIFY_DEPLOYMENT.md

Note: This package includes only the essential files needed for building and deploying the application.
