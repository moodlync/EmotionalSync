// Common types for the application
export type TabType = 'connect' | 'map' | 'journal' | 'ai' | 'premium' | 'gamification';